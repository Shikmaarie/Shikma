import * as React from "react";
import { cn } from "@/lib/utils";

export const Label = ({ className, ...p }: React.LabelHTMLAttributes<HTMLLabelElement>) => (
  <label className={cn("text-sm font-medium leading-snug", className)} {...p} />
);
